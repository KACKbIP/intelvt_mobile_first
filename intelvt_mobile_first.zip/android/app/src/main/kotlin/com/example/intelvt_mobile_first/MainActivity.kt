package com.example.intelvt_mobile_first

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
