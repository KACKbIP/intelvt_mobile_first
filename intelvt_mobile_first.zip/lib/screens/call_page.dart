import 'dart:io';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../services/api_client.dart';

class CallPage extends StatefulWidget {
  final Map<String, dynamic> args;
  const CallPage({super.key, required this.args});

  @override
  State<CallPage> createState() => _CallPageState();
}

class _CallPageState extends State<CallPage> {
  RtcEngine? _engine;

  bool _joined = false;
  int? _remoteUid;

  String _status = 'init';
  String? _err;

  ConnectionStateType? _connState;
  ConnectionChangedReasonType? _connReason;

  late final String _appId;
  late final String _channel;
  late int _uid;
  late String _token;

  // Включай, если сеть режет UDP (часто это и есть проблема "connecting")
  static const bool _forceTcp = true;
  static const bool _enableProxy = true;

  bool _refreshingToken = false;
  DateTime? _lastTokenRefreshAt;

  void _log(String msg) {
    if (kDebugMode) debugPrint('[PARENT] $msg');
  }

  bool get _badArgs => _appId.isEmpty || _channel.isEmpty || _uid <= 0;

  @override
  void initState() {
    super.initState();
    final a = widget.args;

    _appId = (a['agoraAppId'] ?? a['appId'] ?? '').toString();
    _channel = (a['channelName'] ?? a['channel'] ?? '').toString().trim();
    _uid = int.tryParse((a['uid'] ?? '0').toString()) ?? 0;
    _token = (a['agoraToken'] ?? a['token'] ?? '').toString();

    _log('args: appIdLen=${_appId.length} ch=$_channel uid=$_uid tokenLen=${_token.length}');
    _initAgora();
  }

  Future<void> _initAgora() async {
    try {
      if (_badArgs) {
        setState(() {
          _status = 'bad args';
          _err = 'appId/channel/uid пустые (uid должен быть > 0)';
        });
        return;
      }

      setState(() => _status = 'permissions...');
      final res = await [
        Permission.microphone,
        Permission.camera,
        if (!kIsWeb && Platform.isAndroid) Permission.notification,
      ].request();

      if (res[Permission.microphone] != PermissionStatus.granted ||
          res[Permission.camera] != PermissionStatus.granted) {
        setState(() {
          _status = 'permissions denied';
          _err = 'Нет доступа к камере/микрофону';
        });
        return;
      }

      setState(() => _status = 'engine init...');
      final engine = createAgoraRtcEngine();

      // ✅ Надёжно для видео-вызова
      await engine.initialize(
        RtcEngineContext(
          appId: _appId,
          channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
        ),
      );

      _engine = engine;
      await engine.setLogLevel(LogLevel.logLevelInfo);

      // ✅ Если UDP режется — спасают эти параметры
      if (_forceTcp) {
        await engine.setParameters('{"rtc.force_tcp":true}');
        _log('force_tcp enabled');
      }
      if (_enableProxy) {
        await engine.setParameters('{"rtc.enable_proxy":true}');
        await engine.setParameters('{"rtc.use_cloud_proxy":true}');
        _log('proxy enabled');
      }

      // (опционально) послабее видео для стабильности
      await engine.setVideoEncoderConfiguration(
        const VideoEncoderConfiguration(
          dimensions: VideoDimensions(width: 640, height: 360),
          frameRate: 15,
          bitrate: 400,
        ),
      );

      engine.registerEventHandler(
        RtcEngineEventHandler(
          onConnectionStateChanged: (connection, state, reason) async {
            _connState = state;
            _connReason = reason;
            _log('connState=$state reason=$reason');
            if (!mounted) return;
            setState(() => _status = 'connState=$state reason=$reason');

            if (reason == ConnectionChangedReasonType.connectionChangedInvalidToken) {
              await _refreshTokenAndRecover('reason=InvalidToken');
            }
          },

          onConnectionLost: (connection) {
            _log('connection lost');
            if (!mounted) return;
            setState(() {
              _err = 'CONNECTION_LOST';
              _status = 'lost';
            });
          },

          onNetworkQuality: (connection, uid, txQuality, rxQuality) {
            _log('net quality uid=$uid tx=$txQuality rx=$rxQuality');
          },

          onRtcStats: (connection, stats) {
            _log('rtcStats tx=${stats.txKBitRate} rx=${stats.rxKBitRate} users=${stats.userCount}');
          },

          onJoinChannelSuccess: (connection, elapsed) {
            _log('join success ch=${connection.channelId} localUid=${connection.localUid}');
            if (!mounted) return;
            setState(() {
              _joined = true;
              _status = 'joined uid=${connection.localUid}';
            });
          },

          onUserJoined: (connection, remoteUid, elapsed) {
            _log('remote joined uid=$remoteUid');
            if (!mounted) return;
            setState(() => _remoteUid = remoteUid);
          },

          onUserOffline: (connection, remoteUid, reason) {
            _log('remote offline uid=$remoteUid reason=$reason');
            if (!mounted) return;
            setState(() {
              if (_remoteUid == remoteUid) _remoteUid = null;
            });
          },

          onError: (err, msg) async {
            _log('ERROR $err $msg');
            if (!mounted) return;
            setState(() {
              _err = '$err $msg';
              _status = 'error';
            });

            final s = ('$msg').toLowerCase();
            if (s.contains('invalid token') || s.contains('token')) {
              await _refreshTokenAndRecover('onError token');
            }
          },

          onRequestToken: (connection) async {
            _log('onRequestToken => token invalid/expired');
            if (!mounted) return;
            setState(() => _err = 'TOKEN_INVALID_OR_EXPIRED');
            await _refreshTokenAndRecover('onRequestToken');
          },

          onTokenPrivilegeWillExpire: (connection, token) async {
            _log('onTokenPrivilegeWillExpire => refresh token soon');
            await _refreshTokenOnly('willExpire');
          },
        ),
      );

      await engine.enableAudio();
      await engine.enableVideo();

      // ✅ важно для liveBroadcasting
      await engine.setClientRole(role: ClientRoleType.clientRoleBroadcaster);

      await engine.startPreview();

      if (_token.isEmpty) {
        setState(() => _status = 'fetch token...');
        _token = await ApiClient.getRtcToken(channel: _channel, uid: _uid);
      }

      setState(() => _status = 'joining...');
      await engine.joinChannel(
        token: _token,
        channelId: _channel,
        uid: _uid,
        options: const ChannelMediaOptions(
          channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
          clientRoleType: ClientRoleType.clientRoleBroadcaster,
        ),
      );
    } catch (e) {
      _log('init exception: $e');
      if (!mounted) return;
      setState(() {
        _err = e.toString();
        _status = 'init exception';
      });
    }
  }

  Future<void> _refreshTokenOnly(String why) async {
    if (_refreshingToken) return;
    _refreshingToken = true;

    try {
      _log('Refreshing token ($why)...');
      final newToken = await ApiClient.getRtcToken(channel: _channel, uid: _uid);
      _token = newToken;

      final engine = _engine;
      if (engine != null) {
        await engine.renewToken(newToken);
        _log('renewToken OK');
      }
      if (mounted) setState(() => _err = null);
    } catch (e) {
      _log('refreshTokenOnly error: $e');
      if (mounted) setState(() => _err = 'refreshTokenOnly: $e');
    } finally {
      _refreshingToken = false;
    }
  }

  Future<void> _refreshTokenAndRecover(String why) async {
    final now = DateTime.now();
    if (_lastTokenRefreshAt != null &&
        now.difference(_lastTokenRefreshAt!) < const Duration(seconds: 5)) {
      _log('Skip token refresh (too frequent)');
      return;
    }
    _lastTokenRefreshAt = now;

    if (_refreshingToken) return;
    _refreshingToken = true;

    try {
      _log('Refreshing token+recover ($why)...');
      final newToken = await ApiClient.getRtcToken(channel: _channel, uid: _uid);
      _token = newToken;

      final engine = _engine;
      if (engine == null) return;

      await engine.renewToken(newToken);
      _log('renewToken OK');

      if (!_joined) {
        _log('Not joined yet => leave+join with new token');
        try {
          await engine.leaveChannel();
        } catch (_) {}
        await engine.joinChannel(
          token: _token,
          channelId: _channel,
          uid: _uid,
          options: const ChannelMediaOptions(
            channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
            clientRoleType: ClientRoleType.clientRoleBroadcaster,
          ),
        );
      }

      if (mounted) setState(() => _err = null);
    } catch (e) {
      _log('refreshTokenAndRecover error: $e');
      if (mounted) setState(() => _err = 'refreshTokenAndRecover: $e');
    } finally {
      _refreshingToken = false;
    }
  }

  Future<void> _hangUp() async {
    try {
      await _engine?.leaveChannel();
      await _engine?.release();
    } catch (_) {}
    if (!mounted) return;
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _engine?.release();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final engine = _engine;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Видеозвонок'),
        actions: [
          IconButton(onPressed: _hangUp, icon: const Icon(Icons.call_end)),
        ],
      ),
      body: _badArgs
          ? const Center(
              child: Text(
                'Пустые данные appId/channel/uid',
                style: TextStyle(color: Colors.white),
                textAlign: TextAlign.center,
              ),
            )
          : Stack(
              children: [
                Positioned.fill(
                  child: (_remoteUid == null || engine == null)
                      ? const Center(
                          child: Text(
                            'Ожидание подключения…',
                            style: TextStyle(color: Colors.white, fontSize: 18),
                          ),
                        )
                      : AgoraVideoView(
                          controller: VideoViewController.remote(
                            rtcEngine: engine,
                            canvas: VideoCanvas(uid: _remoteUid),
                            connection: RtcConnection(channelId: _channel),
                          ),
                        ),
                ),
                Positioned(
                  right: 12,
                  top: 12,
                  width: 160,
                  height: 220,
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(color: Colors.white24)),
                    child: (_joined && engine != null)
                        ? AgoraVideoView(
                            controller: VideoViewController(
                              rtcEngine: engine,
                              canvas: const VideoCanvas(uid: 0),
                            ),
                          )
                        : const SizedBox.shrink(),
                  ),
                ),
                Positioned(
                  left: 12,
                  right: 12,
                  bottom: 12,
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.55),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white24),
                    ),
                    child: Text(
                      'status: $_status\n'
                      'state: ${_connState ?? "-"}\n'
                      'reason: ${_connReason ?? "-"}\n'
                      'ch: $_channel\n'
                      'uid(local): $_uid\n'
                      'tokenLen: ${_token.length}\n'
                      'remoteUid: ${_remoteUid ?? "-"}\n'
                      'err: ${_err ?? "-"}',
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
