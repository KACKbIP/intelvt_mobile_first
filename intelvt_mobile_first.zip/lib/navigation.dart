import 'package:flutter/material.dart';

/// Глобальный ключ навигации,
/// чтобы открывать экраны из background / уведомлений
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
