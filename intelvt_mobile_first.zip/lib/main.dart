import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'firebase_options.dart';
import 'navigation.dart';
import 'screens/login_page.dart';
import 'services/incoming_call_notifications.dart';
import 'screens/call_page.dart';

Map<String, dynamic>? _initialCallArgs;

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  await initIncomingCallNotifications();

  final data = message.data;
  if (data['type'] == 'incoming_call') {
    await showIncomingCall(data);
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  await initIncomingCallNotifications();

  FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

  await FirebaseMessaging.instance.requestPermission(
    alert: true,
    badge: true,
    sound: true,
  );

  // ✅ если приложение было закрыто и открылось по push
  final initial = await FirebaseMessaging.instance.getInitialMessage();
  if (initial != null && initial.data['type'] == 'incoming_call') {
    _initialCallArgs = Map<String, dynamic>.from(initial.data);
  }

  // ✅ push пришёл когда приложение открыто
  FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
    final data = message.data;
    if (data['type'] == 'incoming_call') {
      await showIncomingCall(data);
    }
  });

  // ✅ пользователь тапнул по уведомлению
  FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) async {
    final data = message.data;
    if (data['type'] == 'incoming_call') {
      navigatorKey.currentState?.pushNamed('/call', arguments: data);
    }
  });

  runApp(MyApp(initialCallArgs: _initialCallArgs));
}

class MyApp extends StatefulWidget {
  final Map<String, dynamic>? initialCallArgs;

  const MyApp({super.key, this.initialCallArgs});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _pushedInitial = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // ✅ пушим экран звонка после того, как MaterialApp уже построен
    if (!_pushedInitial && widget.initialCallArgs != null) {
      _pushedInitial = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        navigatorKey.currentState?.pushNamed('/call', arguments: widget.initialCallArgs);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IntelVT',
      debugShowCheckedModeBanner: false,
      navigatorKey: navigatorKey,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      home: const LoginPage(),
      onGenerateRoute: (settings) {
        if (settings.name == '/call') {
          final args = (settings.arguments is Map)
              ? Map<String, dynamic>.from(settings.arguments as Map)
              : <String, dynamic>{};
          return MaterialPageRoute(builder: (_) => CallPage(args: args));
        }
        return null;
      },
    );
  }
}
